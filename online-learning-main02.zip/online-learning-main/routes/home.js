const express = require('express')
const router = express.Router()
const nodemailer = require('nodemailer')


router.get('/',(req,res) =>{
    try{
        res.render('home')
    }
    catch{
        res.status(404).json({success:false})
    }
})

router.get('/home',(req,res) =>{
    try{
        res.render('home')
    }
    catch{
        res.status(404).json({success:false})
    }
})


router.get('/visionary-team',(req,res) =>{
    try{
        res.render('VisionaryTeam')
    }
    catch{
        res.status(404).json({success:false})
    }
})

router.get('/execution-team',(req,res) =>{
    try{
        res.render('execution')
    }
    catch{
        res.status(404).json({success:false})
    }
})

router.get('/mba',(req,res) =>{
    try{
        res.render('mba')
    }
    catch{
        res.status(404).json({success:false})
    }
})

router.get('/mca',(req,res) =>{
    try{
        res.render('mca')
    }
    catch{
        res.status(404).json({success:false})
    }
})

router.get('/mba-people',(req,res) =>{
    try{
        res.render('mba_people')
    }
    catch{
        res.status(404).json({success:false})
    }
})

router.get('/mba-eligiblity',(req,res) =>{
    try{
        res.render('mba_eligiblity')
    }
    catch{
        res.status(404).json({success:false})
    }
})

router.get('/mba-syllabus',(req,res) =>{
    try{
        res.render('mba_syllabus')
    }
    catch{
        res.status(404).json({success:false})
    }
})

router.get('/mca-people',(req,res) =>{
    try{
        res.render('mca_people')
    }
    catch{
        res.status(404).json({success:false})
    }
})

router.get('/mca-eligiblity',(req,res) =>{
    try{
        res.render('mca_eligiblity')
    }
    catch{
        res.status(404).json({success:false})
    }
})

router.get('/mca-syllabus',(req,res) =>{
    try{
        res.render('mca_syllabus')
    }
    catch{
        res.status(404).json({success:false})
    }
})

router.get('/how-to-apply',(req,res) =>{
    try{
        res.render('How_To_Apply')
    }
    catch{
        res.status(404).json({success:false})
    }
})



router.post('/send',(req,res)=>{

    // const emailIds = ['director.cresoline@crescent.education','jaya@crescent.education','thowseaf@crescent.education']
    const emailIds = ['director.cresoline@crescent.education','jaya@crescent.education','thowseaf@crescent.education']
    const {name,email,phone,message} = req.body
    console.log(req.body);
    const output = `
        <h2>You have a new query</h2>
        <h3>Contact details</h3>
        <ul>
            <li>Name: ${name}</li>
            <li>Contact No.: ${phone}</li>
            <li>Email: ${email}</li>
        </ul>
        <h3>Message:</h3>
        <p>${message}</p>
    `
    emailIds.forEach(function(e){
        console.log(e);
        try{
            let transporter = nodemailer.createTransport({
                host: 'smtp.gmail.com',
                port: 587,
                secure: false,
                auth: {
                    user: 'cdoesupport@crescent.education', 
                    pass: 'idjoolesuqswojwi'
                },
                tls:{
                  rejectUnauthorized:false
                }
            });
            
            let mailOptions = {
                from: '<cdoesupport@crescent.education>', 
                to: e, 
                subject: 'New query received', 
                html: output 
                
            };
            
            transporter.sendMail(mailOptions, (error, info) => {
                if (error) {
                    return console.log(error);
                }
                console.log('Message sent: %s', info.messageId);   
                console.log('Preview URL: %s', nodemailer.getTestMessageUrl(info));
                res.redirect('/')
            });
    
        }catch(err){
            res.status(404).json({success:false})
            console.log(err);
        }
    })
    
})
















module.exports = router